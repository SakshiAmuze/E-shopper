import React from 'react'

export default function Left() {
  return (
    <div>Left</div>
  )
}
