export default{
    apipath:'https://fakestoreapi.com',
    nodeapipath:'http://localhost:9050'
}